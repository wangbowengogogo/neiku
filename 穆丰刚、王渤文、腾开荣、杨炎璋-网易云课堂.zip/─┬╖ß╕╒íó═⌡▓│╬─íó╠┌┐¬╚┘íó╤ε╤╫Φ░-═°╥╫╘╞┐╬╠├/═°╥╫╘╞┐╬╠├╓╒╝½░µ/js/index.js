$(function () {

    // 头部的隐藏和出现
    scroll();
    function scroll() {
        if ($(document).scrollTop() >= 600) {
            $('.header').fadeIn();
        } else {
            $('.header').fadeOut();
        }
    }
    $(window).scroll(function () {
        scroll();
    });

    // 搜索 课程的隐藏和出现
    $('header .search>div').hover(function () {
        $(this).children('ul').stop().slideToggle();
    })
	



    // 隐藏首页的课程导航的隐藏和出现
    $('.header .course').mouseover(function () {
        $(this).children('.course1').show();
    });
	$('.header .course').mouseout(function () {
	    $(this).children('.course1').hide();
	});
	
	/* // 隐藏首页的课程导航的隐藏和出现
	$('.footdiv .course').mouseover(function () {
	    $(this).children('.course1').show();
	});
	$('.footdiv .course1').mouseout(function () {
	    $(this).children('.course1').hide();
	}); */

    // 隐藏首页的关注领福利二维码的隐藏和出现
    $('.header .welfare').mouseover(function () {
        $(this).children('.ewm').show();
    });
	$('.header .welfare').mouseout(function () {
	    $(this).children('.ewm').hide();
	});

    // 搜索 课程的隐藏和出现
    $('.header .search>div').mouseover(function () {
        $(this).children('ul').show();
    })
	$('.header .search>div').mouseout(function () {
	    $(this).children('ul').hide();
	})


    // $(".nav>li").hover(function () {
    //     // stop 方法必须写到动画的前面
    //     $(this).children("ul").stop().slideToggle();
    //   });


$("#uls>li").click(function(){
				var index = $(this).index()
				
				$(this).css("background","#49AF4F").siblings(".lis").css("background","#ECF7ED");
//				获取某个元素在同级标签中的索引值
//				console.log($(this).index());
				$(".divs").eq(index).css("display","inline-block").siblings(".divs").css("display","none");
			})

})
$(".dis-img").eq(0).mouseover(function (){
	$(".dis-none").addClass("dis-block");
})
$(".dis-img").eq(0).mouseout(function (){
	$(".dis-none").removeClass("dis-block");
})

//轮播图------------------------------------------
var i = 0;
			//轮播图背景颜色
			var arr = ["rgb(41,37,134)", "rgb(42,43,185)", "rgb(51,17,111)", "rgb(249,212,1)", "rgb(255,198,37)", "rgb(35,25,111)", "rgb(32,93,173)"];

			var show_length = $(".ga-click").length;
		var timer=iLunbo();

			function iLunbo() {
				timer = setInterval(function() {
					++i;
					if(i == show_length) {
						i = 0;
					}
					console.log("1" + i);
					startLunbo();
				}, 2000)
				//				console.log(1)
			}

			function startLunbo() {

				$(".bg-color").eq(0).css({
					"background-color": arr[i]
				});
				$(".th-fs1fc5").eq(i).addClass("th-bg0").siblings().removeClass("th-bg0");
				$(".ga-click").eq(i).addClass("fadeIn").siblings().removeClass("fadeIn");
			}

			$(".th-fs1fc5").mouseover(function() {
//				clearInterval(timer);
//				setTimeout(function() {

					i = $(this).index();
					$(".bg-color").eq(0).css({
						"background-color": arr[i]
					});
					$(this).addClass("th-bg0").siblings().removeClass("th-bg0");
					$(".ga-click").eq(i).addClass("fadeIn").siblings().removeClass("fadeIn");
//				}, 500)
//				timer=startLunbo();
			})